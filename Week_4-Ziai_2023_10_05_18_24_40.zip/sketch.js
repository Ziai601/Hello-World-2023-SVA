let numWaves = 10;

function setup() {
  createCanvas(800, 600);
  colorMode(500, 360, 100, 100); 
}

function draw() {
  background(200, 30, 80); 

  for (let i = 0; i < numWaves; i++) {
    let yOffset = map(i, 0, numWaves - 1, height * 0.2, height * 0.8);
    drawWave(yOffset);
  }
}

function drawWave(yOffset) {
  let hue = random(360); // Randomize the hue for each wave
  let saturation = random(50, 80); // Randomize saturation for vibrant colors
  let brightness = random(70, 90); // Randomize brightness for variety

  stroke(hue, saturation, brightness); // Set stroke color based on random HSB values
  strokeWeight(2);

  let waveFrequency = random(0.005, 0.15); // Randomize wave frequency
  let waveAmplitude = random(20, 40); // Randomize wave amplitude
  let waveSpeed = random(0.5, 2); // Randomize wave speed

  beginShape();
  for (let x = 0; x < width; x += 5) {
    let y = yOffset + sin(x * waveFrequency + frameCount * waveSpeed) * waveAmplitude;
    vertex(x, y);
  }
  endShape();
}

function mouseMoved() {
  numWaves = int(map(mouseX, 0, width, 2, 20)); 
}
